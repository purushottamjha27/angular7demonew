

import { FormGroup, FormControl, Validators } from '@angular/forms';


export class Meeting {  
    constructor()
    {

    }
        meetingForm : FormGroup = new FormGroup({
        Meetingid: new FormControl() , 
        Meetingsubject: new FormControl('',Validators.required) , 
        Agenda: new FormControl('',Validators.required), 
        Attendees: new FormControl() , 
        ListAttendee:new FormControl('',Validators.required),
        CreatedDate: new FormControl('' ,Validators.required) , 
        UserName : new FormControl('' ),
        Userid : new FormControl('')
        
    })
}  


