import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MeetingService } from '../meeting.service';
import { Meeting } from '../meeting'
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-meetingdetails',
  templateUrl: './meetingdetails.component.html',
  styleUrls: ['./meetingdetails.component.css']
})
export class MeetingDetailsComponent implements OnInit {
  meetings: Meeting[];
  meeting: Meeting;
  gridapi: any;
  gridColumnApi: any;
  sortingOrders: any;
  columnDefs: any;
  Meetingid: number;


  constructor(private meetingService: MeetingService, private router: Router, private route: ActivatedRoute, private datepipe: DatePipe) {

    this.route.paramMap.subscribe(params => {
      // console.log(params.get("id"));
      this.Meetingid = +params.get("Meetingid");
    })
    var valueofdatetime = this;

  

    this.columnDefs = [
      {
        headerName: 'Meeting Subject',
        field: 'Meetingsubject',
        tooltipField: 'Meetingsubject',
        sortable: true,
        filter: true
      },
      {
        headerName: 'Agenda',
        field: 'Agenda',
        tooltipField: 'Agenda',
        sortable: true,
        filter: true
      },
      {
        headerName: 'Attendees',
        width: 448,
        tooltipField: 'Attendees',
        field: 'Attendees',
        sortable: true,
        filter: true
      },
      {
        headerName: 'Meeting DateTime',
        field: 'CreatedDate',
        sortable: true,
        filter: true,
        cellRenderer: function (data) {
          return valueofdatetime.datepipe.transform(data.data.CreatedDate, 'yyyy-MM-dd  hh:mm a');
        }
      },
      {
        headerName: 'Action',
        field: 'edit',
        width: 90,
        filter: false,
        autoHeight: true,
        cellRenderer: function (data) {
          return ' <button  class="btn btn-info btn-sm">Update</button>';
        },
        onCellClicked: (data) => {
          //this.router.navigate(['/Meeting'])
          this.router.navigate(['/Meeting']);
          this.meetingService.passData(data.data);
          //   console.log( data.data.Meetingid);
        },
      },

      // {
      //   headerName: 'Action',
      //   field: 'test',
      //   width: 90,
      //   autoHeight: true,
      //   filter: false,
      //   cellRenderer: function (data) {
      //     return ' <button  class="btn btn-info btn-sm"> delete</button>';
      //   },
      //   onCellClicked: (data) => {
      //     this.meetingService.test(data.data.Meetingid)
      //       .subscribe(data => {
      //       }
      //         , error => {
      //         }
      //         ,

      //         () => { this.GetMeetingDetails() }
      //       );
      //     //   console.log( data.data.Meetingid);
      //   },

      // }
    ];
 
  }
  gridOperationCellRenderer() {
  }
  ngOnInit() {
    this.GetMeetingDetails();
  }
  AddMeeting() {
    this.router.navigate(['/meeting']);
  }

  GetMeetingDetails() {
    this.meetingService.getAllMeeting()
      .subscribe(
        data => {
          this.meetings = data
        }, error => {
          console.log(error["status"]);
        });
  }
}
