


export class Attendee {    
    Userid:Number;     
    FullName :string;

}
 