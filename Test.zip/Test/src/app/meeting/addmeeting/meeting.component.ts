import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MeetingService } from '../meeting.service'
import { Meeting } from '../meeting'
import { Attendee } from '../attendee';
import { DatepickerOptions } from 'ng2-datepicker';
@Component({
  selector: 'app-meeting',
  templateUrl: './meeting.component.html',
  styleUrls: ['./meeting.component.css']
})
export class MeetingComponent implements OnInit {
  minDate: Date;
  dropdownList: Attendee[];
  selectedItems: Attendee[] = [];
  loading = false;
  btntxt: string;
  submitted = false;
  dropdownSettings = {};
  meeting: Meeting = new Meeting();
  meetingEditData: Meeting = new Meeting();
  selectedListData: Attendee[];
  isMeetingDateValid :boolean=true;
  Meetingstatus: string;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private meetingService: MeetingService,
  ) {
    this.minDate = this.addDays(0);
    console.log(this.minDate);
    this.btntxt = "SaveMeeting";
    this.Meetingstatus= "Add Meeting"
  }

  onReset() {
    this.meeting.meetingForm.reset();
  }

  onSubmit() {

    this.submitted = true;

    // stop here if form is invalid
    console.log(this.meeting.meetingForm);
    let selectedDate = this.meeting.meetingForm.value["CreatedDate"]
    selectedDate = new Date(selectedDate);
    let currentDate = new Date();
    if (selectedDate.getTime() < currentDate.getTime()) {
     this.isMeetingDateValid=false;

     console.log(this.isMeetingDateValid)
      return;
    }
    this.isMeetingDateValid=true;

    console.log(this.meeting.meetingForm);
    if (this.meeting.meetingForm.invalid) {

      return;
    }
   

    //this.meeting.meetingForm.patchValue({ 
    //CreatedDate:this.convertUTCDateToLocalDate(new Date(this.meeting.meetingForm.value["CreatedDate"]))
    // formControlName2: myValue2 (can be omitted)
    // });

    this.loading = false;
    debugger
    console.log(this.meeting.meetingForm.value);
    this.meeting.meetingForm.patchValue({

      Userid: sessionStorage.getItem("UserId")
      // formControlName2: myValue2 (can be omitted)
    });
    this.meetingService.SaveMeeting(this.meeting.meetingForm.value).subscribe(
      data => {
        this.router.navigate(['/MeetingDetails']);
        console.log(data);
      }, error => {
        console.log();
      });
  }
  ngOnInit() {
   
    this.meetingService.currentData.subscribe(mtg => this.meetingEditData = mtg);
    if (this.meetingEditData != null && this.meetingEditData["Meetingid"] != undefined) {
      this.btntxt = "UpdateMeeting";
      this.Meetingstatus= 'Update Meeting';
      //this.meeting= new Meeting();
      this.meeting.meetingForm.patchValue({
        Agenda: this.meetingEditData["Agenda"],
        Meetingid: this.meetingEditData["Meetingid"],
        Meetingsubject: this.meetingEditData["Meetingsubject"],
        Attendees: this.meetingEditData["Attendees"],
        ListAttendee: this.meetingEditData["ListAttendee"],
        CreatedDate: this.meetingEditData["CreatedDate"],
        // formControlName2: myValue2 (can be omitted)
      });
      // this.selectedListData = this.meetingEditData["ListAttendee"];
      //    console.log(this.selectedListData);
      this.meetingEditData = new Meeting();
      this.meetingService.passData(this.meetingEditData);
    }

    this.meetingService.GetMeetingAttendee().subscribe(
      data => {
        this.dropdownList = data
        console.log(this.dropdownList);
      }, error => {
      });
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'Userid',
      textField: 'FullName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 20,
      limitSelection: 10,
      allowSearchFilter: true
    };
  }

  convertUTCDateToLocalDate(date: Date) {
    var newDate = new Date(date.getTime() + date.getTimezoneOffset() * 60 * 1000);

    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();

    newDate.setHours(hours - offset);

    return newDate;
  }

  onItemSelect(item: any) {
    this.selectedItems.push(item);
    console.log(item);
  }
  onSelectAll(items: any) {
    this.selectedItems.push(items);
    console.log(items);
  }
  get f() {
    return this.meeting.meetingForm.controls;
  }
  resetControl() {
    this.meeting.meetingForm.reset();
  }
  getHoursTime(): string {
    var date = new Date();

    var minutes = date.getMinutes();
    var hour = date.getHours();
    return hour + ':' + minutes
  }
  addDays(days: number): Date {
    var date = new Date();
    date.setDate(date.getDate() + days);
    return date;
  }
  minusDays(days: number): Date {
    var date = new Date();
    date.setDate(date.getDate() - days);
    return date;
  }
}