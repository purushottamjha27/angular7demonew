import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Meeting } from './meeting';
import { Attendee } from './attendee';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class MeetingService {
  baseurl = environment.apiurl;
  constructor(private http: HttpClient) { }
  strMeetingOperationPath:string;
  meeting : Meeting;

  //call Subject to get the data once data changes 
  private messageSource = new BehaviorSubject(this.meeting);
  currentData = this.messageSource.asObservable();


  passData(meeting : Meeting) {
    this.messageSource.next(meeting);
    console.log(meeting)
  }
  
  
  getAllMeeting(): Observable<Meeting[]> {
  
    return this.http.get<Meeting[]>(this.baseurl + 'api/Meeting/GetMeetingDetails/?userId=' + sessionStorage.getItem("UserId"))
  }


  GetMeetingAttendee(): Observable<Attendee[]> {

    return this.http.get<Attendee[]>(this.baseurl + 'api/Meeting/GetMeetingAttendee')
  }
  SaveMeeting(meeting: Meeting) {
    if(meeting["Meetingid"]!='' && meeting["Meetingid"]!=null)
      {
        this.strMeetingOperationPath="UpdateMeeting"
        return this.http.put(this.baseurl + 'api/Meeting/'+ this.strMeetingOperationPath, meeting)

      }
      else{
         this.strMeetingOperationPath="InsertMeeting"
         return this.http.post(this.baseurl + 'api/Meeting/'+ this.strMeetingOperationPath, meeting)

      }
      
     }

    //  test(meetingId )  { 
  ///let vale= this.http.test(this.baseurl  + 'api/Meeting/test/?meetingid='+meetingId, httpOptions)
      // return this.http.test(this.baseurl + 'api/Meeting/test/?meetingid=' + meetingId)
    // }
 
}