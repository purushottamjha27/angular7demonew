import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable()
export class AuthService {
  constructor(private myRoute: Router) { }


  sendToken(token: string) {
    localStorage.setItem("token", token)
  }

  getToken() {
    return localStorage.getItem("token")
  }

  isLoggednIn() {
    return this.getToken() !== null;
  }

  logout() {
    localStorage.removeItem("token");
    sessionStorage.removeItem("UserId");
    sessionStorage.removeItem("UserName"); 
    this.myRoute.navigate(["login"]);
  }
  RemoveToken() {
    localStorage.removeItem("token");
     
  }
}