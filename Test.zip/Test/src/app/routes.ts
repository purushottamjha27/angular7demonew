import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { MeetingComponent } from './meeting/addmeeting/meeting.component'
import { MeetingDetailsComponent } from './meeting/meetingdetails/meetingdetails.component';
import { AuthGuard } from './meeting/auth/auth-guard';
    const appRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'login', component: LoginComponent },
    { path: 'MeetingDetails', component: MeetingDetailsComponent, canActivate: [AuthGuard] },
    { path: 'Meeting', component: MeetingComponent , canActivate: [AuthGuard]},
    { path: 'Meeting/:Meetingid', component: MeetingComponent, canActivate: [AuthGuard] },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing: ModuleWithProviders= RouterModule.forRoot(appRoutes);