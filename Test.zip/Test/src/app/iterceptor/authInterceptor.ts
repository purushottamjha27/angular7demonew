import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http'; 
import{Observable} from  "rxjs"
import { AuthService } from '../meeting/auth/AuthService';
import 'rxjs/add/operator/do';
 
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  public onlineFlag =navigator.onLine;

  constructor(  private auth : AuthService )
  {
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    var idToken = this.auth.getToken();
    if(idToken)
    {
       const cloned=req.clone(
         {
           headers: req.headers.set('Authorization', 'bearer ' + idToken)         
         })
         return   next.handle(cloned);
    }
    else
    {    
      return next.handle(req).do((event: HttpEvent<any>) => {}, (err: any) => {
        if (err instanceof HttpErrorResponse) {
          this.handleError(err);
        }
      });
  
      }
    }
    public handleError(err: any) {   
     // console.log(err.message);
     // console.log(err.status);

      if(err.status==401)
      {
        console.log( 'Some problem occur on our end')
      }
      else if(err.status==400)
      {
        console.log( 'Some problem occur on our end')
      }
      else if(!this.onlineFlag)
      {
        console.log( 'Service is not working.')
        
      }
    }
  }

  



  